package com.example.koin

class MainRepository {
}