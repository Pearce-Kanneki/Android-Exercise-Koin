package com.example.koin

class HoneyLemonade(val honey:Honey, val lemon: Lemon)

class Honey(val bee:Bee)

class Bee

class Lemon