package com.example.koin

import android.arch.lifecycle.ViewModel


class MainViewModel(): ViewModel() {


}